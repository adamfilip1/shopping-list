var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shoppinglist/delete/route.js")
R.c("server/chunks/node_modules_next_4059ffd9._.js")
R.c("server/chunks/[root-of-the-server]__25d936c9._.js")
R.c("server/chunks/_next-internal_server_app_api_shoppinglist_delete_route_actions_dbd7b440.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/shoppinglist/delete/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/shoppinglist/delete/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
