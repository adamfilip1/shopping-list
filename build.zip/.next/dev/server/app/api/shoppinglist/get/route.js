var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shoppinglist/get/route.js")
R.c("server/chunks/node_modules_next_c06220d7._.js")
R.c("server/chunks/[root-of-the-server]__035053da._.js")
R.c("server/chunks/_next-internal_server_app_api_shoppinglist_get_route_actions_6cbd24af.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/shoppinglist/get/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/shoppinglist/get/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
