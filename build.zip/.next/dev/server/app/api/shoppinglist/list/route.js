var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shoppinglist/list/route.js")
R.c("server/chunks/node_modules_next_6130138c._.js")
R.c("server/chunks/[root-of-the-server]__de7b84a8._.js")
R.c("server/chunks/_next-internal_server_app_api_shoppinglist_list_route_actions_b9c7b95c.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/shoppinglist/list/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/shoppinglist/list/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
