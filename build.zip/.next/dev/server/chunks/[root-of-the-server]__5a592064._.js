module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/mongodb [external] (mongodb, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("mongodb", () => require("mongodb"));

module.exports = mod;
}),
"[project]/src/lib/mongo.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getDb",
    ()=>getDb
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$server$2d$only$2f$empty$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/server-only/empty.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongodb [external] (mongodb, cjs)");
;
;
const uri = process.env.MONGODB_URI;
const dbName = process.env.MONGODB_DB;
if (!uri) throw new Error("Missing MONGODB_URI in .env.local");
if (!dbName) throw new Error("Missing MONGODB_DB in .env.local");
const clientPromise = global._mongoClientPromise ?? new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["MongoClient"](uri).connect();
if ("TURBOPACK compile-time truthy", 1) {
    global._mongoClientPromise = clientPromise;
}
async function getDb() {
    const client = await clientPromise;
    return client.db(dbName);
}
}),
"[project]/src/lib/constants.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AWID",
    ()=>AWID,
    "CURRENT_USER_ID",
    ()=>CURRENT_USER_ID
]);
const AWID = "shoppinglist-main";
const CURRENT_USER_ID = "u-2";
}),
"[project]/src/dao/itemDao.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "add",
    ()=>add,
    "listByListId",
    ()=>listByListId,
    "markComplete",
    ()=>markComplete,
    "remove",
    ()=>remove,
    "update",
    ()=>update
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/mongo.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongodb [external] (mongodb, cjs)");
;
;
;
function toIso(d) {
    const dt = d instanceof Date ? d : new Date(d);
    return dt.toISOString();
}
function idFilter(id) {
    const idAsObjectId = __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"].isValid(id) ? new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id) : null;
    return {
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"],
        $or: [
            ...idAsObjectId ? [
                {
                    _id: idAsObjectId
                }
            ] : [],
            {
                id
            }
        ]
    };
}
async function listByListId(input) {
    const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
    const col = db.collection("item");
    const docs = await col.find({
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"],
        listId: input.listId
    }).sort({
        createdAt: 1
    }).toArray();
    return docs.map((d)=>({
            awid: d.awid ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"],
            id: d._id?.toString?.() ?? d.id,
            listId: d.listId,
            name: d.name,
            quantity: d.quantity,
            status: d.status,
            createdBy: d.createdBy,
            completedBy: d.completedBy ?? null,
            createdAt: toIso(d.createdAt),
            completedAt: d.completedAt ? toIso(d.completedAt) : null
        }));
}
async function add(input) {
    const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
    const col = db.collection("item");
    const now = new Date();
    const doc = {
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"],
        listId: input.listId,
        name: input.name,
        quantity: input.quantity,
        status: "open",
        createdBy: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["CURRENT_USER_ID"],
        completedBy: null,
        createdAt: now,
        completedAt: null
    };
    const res = await col.insertOne(doc);
    return {
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"],
        id: res.insertedId.toString(),
        listId: input.listId,
        name: input.name,
        quantity: input.quantity,
        status: "open",
        createdBy: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["CURRENT_USER_ID"],
        completedBy: null,
        createdAt: now.toISOString(),
        completedAt: null
    };
}
async function update(input) {
    const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
    const col = db.collection("item");
    const doc = await col.findOneAndUpdate(idFilter(input.id), {
        $set: {
            name: input.name,
            quantity: input.quantity
        }
    }, {
        returnDocument: "after"
    });
    if (!doc) {
        throw new Error("Item not found");
    }
    return {
        awid: doc.awid,
        id: doc._id?.toString?.() ?? input.id,
        listId: doc.listId,
        name: doc.name,
        quantity: doc.quantity,
        status: doc.status,
        createdBy: doc.createdBy,
        completedBy: doc.completedBy ?? null,
        createdAt: toIso(doc.createdAt),
        completedAt: doc.completedAt ? toIso(doc.completedAt) : null
    };
}
async function remove(input) {
    const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
    const col = db.collection("item");
    const res = await col.findOneAndDelete(idFilter(input.id));
    if (!res) {
        throw new Error("Item not found");
    }
    return {
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"],
        id: input.id
    };
}
async function markComplete(input) {
    const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
    const col = db.collection("item");
    const now = new Date();
    const set = input.completed ? {
        status: "completed",
        completedBy: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["CURRENT_USER_ID"],
        completedAt: now
    } : {
        status: "open",
        completedBy: null,
        completedAt: null
    };
    const doc = await col.findOneAndUpdate(idFilter(input.id), {
        $set: set
    }, {
        returnDocument: "after"
    });
    if (!doc) {
        throw new Error("Item not found");
    }
    return {
        awid: doc.awid,
        id: doc._id?.toString?.() ?? input.id,
        listId: doc.listId,
        name: doc.name,
        quantity: doc.quantity,
        status: doc.status,
        createdBy: doc.createdBy,
        completedBy: doc.completedBy ?? null,
        createdAt: toIso(doc.createdAt),
        completedAt: doc.completedAt ? toIso(doc.completedAt) : null,
        uuAppErrorMap: {}
    };
}
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[project]/src/dao/mockDb.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ensureSeed",
    ()=>ensureSeed,
    "mockDb",
    ()=>mockDb
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/crypto [external] (crypto, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-route] (ecmascript)");
;
;
function nowIso() {
    return new Date().toISOString();
}
const g = globalThis;
const mockDb = g.__mockDb ?? (g.__mockDb = {
    shoppingLists: new Map(),
    items: new Map(),
    __seeded: false
});
function ensureSeed() {
    if (mockDb.__seeded) return;
    const listId = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__["randomUUID"])();
    mockDb.shoppingLists.set(listId, {
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"],
        id: listId,
        ownerId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["CURRENT_USER_ID"],
        name: "BBQ party",
        members: [
            "6770b0cd123456789000002",
            "6770b0cd123456789000003"
        ],
        isArchived: false,
        createdAt: nowIso()
    });
    const itemId = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__["randomUUID"])();
    mockDb.items.set(itemId, {
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"],
        id: itemId,
        listId,
        name: "Milk",
        quantity: 2,
        status: "open",
        createdBy: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["CURRENT_USER_ID"],
        completedBy: null,
        createdAt: nowIso(),
        completedAt: null
    });
    mockDb.__seeded = true;
}
}),
"[project]/src/dao/itemMockDao.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "add",
    ()=>add,
    "listByListId",
    ()=>listByListId,
    "markComplete",
    ()=>markComplete,
    "remove",
    ()=>remove,
    "update",
    ()=>update
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/crypto [external] (crypto, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$mockDb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/dao/mockDb.ts [app-route] (ecmascript)");
;
;
;
async function listByListId(input) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$mockDb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureSeed"])();
    const items = Array.from(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$mockDb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mockDb"].items.values()).filter((i)=>i.awid === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"] && i.listId === input.listId);
    items.sort((a, b)=>a.createdAt.localeCompare(b.createdAt));
    return items.map((i)=>({
            awid: i.awid,
            id: i.id,
            listId: i.listId,
            name: i.name,
            quantity: i.quantity,
            status: i.status,
            createdBy: i.createdBy,
            completedBy: i.completedBy,
            createdAt: i.createdAt,
            completedAt: i.completedAt
        }));
}
async function add(input) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$mockDb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureSeed"])();
    const now = new Date().toISOString();
    const id = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__["randomUUID"])();
    const item = {
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"],
        id,
        listId: input.listId,
        name: input.name,
        quantity: input.quantity,
        status: "open",
        createdBy: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["CURRENT_USER_ID"],
        completedBy: null,
        createdAt: now,
        completedAt: null
    };
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$mockDb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mockDb"].items.set(id, item);
    return item;
}
async function update(input) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$mockDb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureSeed"])();
    const item = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$mockDb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mockDb"].items.get(input.id);
    if (!item || item.awid !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"]) {
        throw new Error("Item not found");
    }
    item.name = input.name;
    item.quantity = input.quantity;
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$mockDb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mockDb"].items.set(item.id, item);
    return {
        awid: item.awid,
        id: item.id,
        listId: item.listId,
        name: item.name,
        quantity: item.quantity,
        status: item.status,
        createdBy: item.createdBy,
        completedBy: item.completedBy,
        createdAt: item.createdAt,
        completedAt: item.completedAt
    };
}
async function remove(input) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$mockDb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureSeed"])();
    const item = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$mockDb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mockDb"].items.get(input.id);
    if (!item || item.awid !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"]) {
        throw new Error("Item not found");
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$mockDb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mockDb"].items.delete(input.id);
    return {
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"],
        id: input.id
    };
}
async function markComplete(input) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$mockDb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureSeed"])();
    const item = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$mockDb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mockDb"].items.get(input.id);
    if (!item || item.awid !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"]) {
        throw new Error("Item not found");
    }
    const now = new Date().toISOString();
    if (input.completed) {
        item.status = "completed";
        item.completedBy = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["CURRENT_USER_ID"];
        item.completedAt = now;
    } else {
        item.status = "open";
        item.completedBy = null;
        item.completedAt = null;
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$mockDb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mockDb"].items.set(item.id, item);
    return {
        awid: item.awid,
        id: item.id,
        listId: item.listId,
        name: item.name,
        quantity: item.quantity,
        status: item.status,
        createdBy: item.createdBy,
        completedBy: item.completedBy,
        createdAt: item.createdAt,
        completedAt: item.completedAt,
        uuAppErrorMap: {}
    };
}
}),
"[project]/src/dao/itemDaoRouter.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "itemDao",
    ()=>itemDao
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$itemDao$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/dao/itemDao.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$itemMockDao$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/dao/itemMockDao.ts [app-route] (ecmascript)");
;
;
const useMock = process.env.USE_MOCK_DATA === "true";
const itemDao = useMock ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$itemMockDao$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$itemDao$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__;
}),
"[project]/app/api/item/markComplete/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$itemDaoRouter$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/dao/itemDaoRouter.ts [app-route] (ecmascript)");
;
;
async function POST(req) {
    const dtoIn = await req.json();
    const uuAppErrorMap = {};
    const allowedKeys = [
        "id",
        "completed"
    ];
    const unsupported = Object.keys(dtoIn).filter((k)=>!allowedKeys.includes(k));
    if (unsupported.length) {
        uuAppErrorMap.unsupportedKeys = {
            unsupportedKeyList: unsupported
        };
    }
    if (!dtoIn.id || typeof dtoIn.id !== "string") {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            code: "invalidDtoIn",
            message: "DtoIn is not valid.",
            uuAppErrorMap
        }, {
            status: 400
        });
    }
    if (typeof dtoIn.completed !== "boolean") {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            code: "invalidDtoIn",
            message: "DtoIn is not valid.",
            uuAppErrorMap
        }, {
            status: 400
        });
    }
    try {
        const dtoOut = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$dao$2f$itemDaoRouter$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["itemDao"].markComplete({
            id: dtoIn.id,
            completed: dtoIn.completed
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            ...dtoOut,
            uuAppErrorMap
        });
    } catch (e) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            code: "itemNotFound",
            message: "Item does not exist.",
            uuAppErrorMap
        }, {
            status: 404
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__5a592064._.js.map