var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/item/delete/route.js")
R.c("server/chunks/[root-of-the-server]__ea7dae00._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_item_delete_route_actions_60fa8219.js")
R.m(12377)
module.exports=R.m(12377).exports
