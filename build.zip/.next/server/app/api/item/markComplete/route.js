var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/item/markComplete/route.js")
R.c("server/chunks/[root-of-the-server]__ca22153e._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_item_markComplete_route_actions_d254bd29.js")
R.m(69852)
module.exports=R.m(69852).exports
