var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shoppinglist/create/route.js")
R.c("server/chunks/[root-of-the-server]__9700a826._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_shoppinglist_create_route_actions_65f4f26e.js")
R.m(31823)
module.exports=R.m(31823).exports
