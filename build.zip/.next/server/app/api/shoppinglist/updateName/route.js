var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shoppinglist/updateName/route.js")
R.c("server/chunks/[root-of-the-server]__8db88500._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_shoppinglist_updateName_route_actions_41c49d9e.js")
R.m(91826)
module.exports=R.m(91826).exports
