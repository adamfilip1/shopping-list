module.exports=[99975,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_shoppinglist_list_route_actions_b9c7b95c.js.map