module.exports=[19985,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_shoppinglist_removeMember_route_actions_c2f6414f.js.map