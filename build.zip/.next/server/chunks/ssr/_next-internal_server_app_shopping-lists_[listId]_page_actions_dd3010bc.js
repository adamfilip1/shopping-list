module.exports=[14568,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_shopping-lists_%5BlistId%5D_page_actions_dd3010bc.js.map