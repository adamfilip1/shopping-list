module.exports = [
"[project]/.next-internal/server/app/api/shoppinglist/list/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_shoppinglist_list_route_actions_b9c7b95c.js.map