var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/item/markComplete/route.js")
R.c("server/chunks/node_modules_next_50be83b8._.js")
R.c("server/chunks/[root-of-the-server]__5a592064._.js")
R.c("server/chunks/_next-internal_server_app_api_item_markComplete_route_actions_d254bd29.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/item/markComplete/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/item/markComplete/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
