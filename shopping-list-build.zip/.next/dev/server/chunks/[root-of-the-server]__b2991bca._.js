module.exports = [
"[externals]/mongodb [external] (mongodb, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("mongodb", () => require("mongodb"));

module.exports = mod;
}),
"[project]/src/lib/mongo.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getDb",
    ()=>getDb
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongodb [external] (mongodb, cjs)");
;
let client = null;
let db = null;
async function getDb() {
    const uri = process.env.MONGODB_URI;
    const dbName = process.env.MONGODB_DB;
    if (!uri) throw new Error("Missing MONGODB_URI (Mongo is disabled without env).");
    if (!dbName) throw new Error("Missing MONGODB_DB (Mongo is disabled without env).");
    if (!client) client = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["MongoClient"](uri);
    if (!db) {
        await client.connect();
        db = client.db(dbName);
    }
    return db;
}
}),
"[project]/src/dao/shoppingListDao.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addMember",
    ()=>addMember,
    "create",
    ()=>create,
    "get",
    ()=>get,
    "list",
    ()=>list,
    "remove",
    ()=>remove,
    "removeMember",
    ()=>removeMember,
    "updateName",
    ()=>updateName,
    "updateStatus",
    ()=>updateStatus
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongodb [external] (mongodb, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/mongo.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-route] (ecmascript)");
;
;
;
async function create(input) {
    const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
    const col = db.collection("shoppingList");
    const now = new Date();
    const doc = {
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"],
        ownerId: input.ownerId,
        name: input.name,
        members: input.members,
        isArchived: false,
        createdAt: now
    };
    const res = await col.insertOne(doc);
    return {
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"],
        id: res.insertedId.toString(),
        ownerId: input.ownerId,
        name: input.name,
        members: input.members,
        isArchived: false,
        createdAt: now.toISOString()
    };
}
async function get(input) {
    const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
    const col = db.collection("shoppingList");
    let _id;
    try {
        _id = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](input.id);
    } catch  {
        return null;
    }
    const doc = await col.findOne({
        _id,
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"]
    });
    if (!doc) return null;
    return {
        awid: doc.awid,
        id: doc._id.toString(),
        ownerId: doc.ownerId,
        name: doc.name,
        members: doc.members,
        isArchived: doc.isArchived,
        createdAt: doc.createdAt.toISOString()
    };
}
async function list(input) {
    const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
    const col = db.collection("shoppingList");
    const filter = {
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"]
    };
    if (input.ownedOnly) {
        filter.ownerId = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["CURRENT_USER_ID"];
    }
    if (!input.includeArchived) {
        filter.isArchived = false;
    }
    const total = await col.countDocuments(filter);
    const docs = await col.find(filter).sort({
        createdAt: -1
    }).skip(input.pageIndex * input.pageSize).limit(input.pageSize).toArray();
    const itemList = docs.map((d)=>({
            awid: d.awid,
            id: d._id.toString(),
            ownerId: d.ownerId,
            name: d.name,
            members: d.members,
            isArchived: d.isArchived,
            createdAt: d.createdAt.toISOString()
        }));
    return {
        itemList,
        total
    };
}
async function remove(input) {
    const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
    const col = db.collection("shoppingList");
    let _id;
    try {
        _id = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](input.id);
    } catch  {
        return false;
    }
    const res = await col.deleteOne({
        _id,
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"]
    });
    return res.deletedCount === 1;
}
async function addMember(input) {
    const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
    const col = db.collection("shoppingList");
    let _id;
    try {
        _id = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](input.listId);
    } catch  {
        return null;
    }
    const upd = await col.updateOne({
        _id,
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"]
    }, {
        $addToSet: {
            members: input.memberId
        }
    });
    if (upd.matchedCount === 0) return null;
    const doc = await col.findOne({
        _id,
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"]
    });
    if (!doc) return null;
    return {
        awid: doc.awid,
        id: doc._id.toString(),
        ownerId: doc.ownerId,
        name: doc.name,
        members: doc.members,
        isArchived: doc.isArchived,
        createdAt: doc.createdAt.toISOString()
    };
}
async function removeMember(input) {
    const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
    const col = db.collection("shoppingList");
    let _id;
    try {
        _id = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](input.listId);
    } catch  {
        return null;
    }
    const upd = await col.updateOne({
        _id,
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"]
    }, {
        $pull: {
            members: input.memberId
        }
    });
    if (upd.matchedCount === 0) return null;
    const doc = await col.findOne({
        _id,
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"]
    });
    if (!doc) return null;
    return {
        awid: doc.awid,
        id: doc._id.toString(),
        members: doc.members
    };
}
function makeIdFilter(id) {
    const idAsObjectId = __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"].isValid(id) ? new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id) : null;
    return {
        awid: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"],
        $or: [
            ...idAsObjectId ? [
                {
                    _id: idAsObjectId
                }
            ] : [],
            {
                id
            }
        ]
    };
}
function toIso(d) {
    const dt = d instanceof Date ? d : new Date(d);
    return dt.toISOString();
}
function mapOut(doc) {
    return {
        awid: doc.awid ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AWID"],
        id: doc._id?.toString?.() ?? doc.id,
        ownerId: doc.ownerId,
        name: doc.name,
        members: doc.members ?? [],
        isArchived: !!doc.isArchived,
        createdAt: toIso(doc.createdAt)
    };
}
async function updateName(input) {
    const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
    const col = db.collection("shoppingList");
    const filter = {
        ...makeIdFilter(input.id),
        ownerId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["CURRENT_USER_ID"]
    };
    const res = await col.findOneAndUpdate(filter, {
        $set: {
            name: input.name
        }
    }, {
        returnDocument: "after"
    });
    const doc = res?.value ?? res; // pro kompatibilitu s typy
    if (!doc) throw new Error("Shopping list not found");
    return mapOut(doc);
}
async function updateStatus(input) {
    const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
    const col = db.collection("shoppingList");
    const filter = {
        ...makeIdFilter(input.id),
        ownerId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["CURRENT_USER_ID"]
    };
    const res = await col.findOneAndUpdate(filter, {
        $set: {
            isArchived: input.isArchived
        }
    }, {
        returnDocument: "after"
    });
    const doc = res?.value ?? res;
    if (!doc) throw new Error("Shopping list not found");
    return mapOut(doc);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__b2991bca._.js.map