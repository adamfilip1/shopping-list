module.exports = [
"[project]/.next-internal/server/app/api/shoppinglist/create/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_shoppinglist_create_route_actions_65f4f26e.js.map