module.exports = [
"[project]/src/dao/shoppingListDao.ts [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/[root-of-the-server]__b2991bca._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/dao/shoppingListDao.ts [app-route] (ecmascript)");
    });
});
}),
];