var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/item/update/route.js")
R.c("server/chunks/[root-of-the-server]__d0de527c._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_item_update_route_actions_4f230fda.js")
R.m(63025)
module.exports=R.m(63025).exports
