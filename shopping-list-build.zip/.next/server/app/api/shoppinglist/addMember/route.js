var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shoppinglist/addMember/route.js")
R.c("server/chunks/[root-of-the-server]__dc71638e._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_shoppinglist_addMember_route_actions_94af0685.js")
R.m(13879)
module.exports=R.m(13879).exports
