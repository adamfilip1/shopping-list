var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shoppinglist/delete/route.js")
R.c("server/chunks/[root-of-the-server]__dc8d857a._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_shoppinglist_delete_route_actions_dbd7b440.js")
R.m(37250)
module.exports=R.m(37250).exports
