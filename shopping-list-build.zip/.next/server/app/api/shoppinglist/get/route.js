var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shoppinglist/get/route.js")
R.c("server/chunks/[root-of-the-server]__7f08b215._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_shoppinglist_get_route_actions_6cbd24af.js")
R.m(19852)
module.exports=R.m(19852).exports
