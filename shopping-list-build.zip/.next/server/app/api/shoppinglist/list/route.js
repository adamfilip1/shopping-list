var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shoppinglist/list/route.js")
R.c("server/chunks/[root-of-the-server]__827f46c7._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_shoppinglist_list_route_actions_b9c7b95c.js")
R.m(47290)
module.exports=R.m(47290).exports
