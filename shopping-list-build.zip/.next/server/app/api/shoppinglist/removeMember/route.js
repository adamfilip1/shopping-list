var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shoppinglist/removeMember/route.js")
R.c("server/chunks/[root-of-the-server]__0613fa7b._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_shoppinglist_removeMember_route_actions_c2f6414f.js")
R.m(97524)
module.exports=R.m(97524).exports
