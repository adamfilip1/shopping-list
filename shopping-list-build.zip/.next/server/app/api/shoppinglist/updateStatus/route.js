var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/shoppinglist/updateStatus/route.js")
R.c("server/chunks/[root-of-the-server]__faa72f11._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_shoppinglist_updateStatus_route_actions_3433ff90.js")
R.m(9572)
module.exports=R.m(9572).exports
