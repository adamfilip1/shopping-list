module.exports=[88456,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_item_delete_route_actions_60fa8219.js.map