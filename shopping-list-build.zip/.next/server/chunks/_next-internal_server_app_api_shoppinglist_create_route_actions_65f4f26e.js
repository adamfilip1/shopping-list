module.exports=[64484,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_shoppinglist_create_route_actions_65f4f26e.js.map