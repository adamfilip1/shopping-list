module.exports=[29246,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_shoppinglist_delete_route_actions_dbd7b440.js.map