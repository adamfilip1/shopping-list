module.exports=[42060,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_shoppinglist_get_route_actions_6cbd24af.js.map