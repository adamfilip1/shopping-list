module.exports=[13400,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_shoppinglist_updateName_route_actions_41c49d9e.js.map