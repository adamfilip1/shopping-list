module.exports=[38333,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_shoppinglist_updateStatus_route_actions_3433ff90.js.map