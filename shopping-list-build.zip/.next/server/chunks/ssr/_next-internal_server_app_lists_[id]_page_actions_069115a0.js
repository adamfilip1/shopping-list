module.exports=[67364,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_lists_%5Bid%5D_page_actions_069115a0.js.map