module.exports=[77565,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_shopping-lists_page_actions_2a375877.js.map